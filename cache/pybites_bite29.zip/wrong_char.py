def get_index_different_char(chars):
    pass